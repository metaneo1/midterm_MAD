package codingwithmitch.com.recyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: started.");

        initImageBitmaps();
    }

    private void initImageBitmaps(){
        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");

        mImageUrls.add("http://pngimg.com/uploads/spongebob/spongebob_PNG68.png");
        mNames.add("Sponge Bob");

        mImageUrls.add("https://i.pinimg.com/originals/5c/b9/32/5cb93222969e60e2f9dac4b6405ec32c.png");
        mNames.add("Patrick");

        mImageUrls.add("https://www.pnglot.com/pngfile/detail/206-2064450_squidward-dab-wallpaper-character-transparent-spongebob-png.png");
        mNames.add("Squidward");

        mImageUrls.add("https://i.pinimg.com/originals/c8/23/b0/c823b08ef83ac1df14786c09f0819e71.png");
        mNames.add("Sandy");


        mImageUrls.add("https://nick-intl.mtvnimages.com/uri/mgid:file:gsp:kids-assets:/nick/properties/spongebob-squarepants/characters/gary-character-web-desktop.png?height=0&width=480&matte=true&crop=false");
        mNames.add("Gary");

        mImageUrls.add("https://pixy.org/download/4268127/");
        mNames.add("Krabs");


        mImageUrls.add("https://webstockreview.net/images/clipart-house-spongebobs-11.png");
        mNames.add("Perl");

        mImageUrls.add("https://www.trzcacak.rs/myfile/detail/236-2364020_mrs-puff-nickelodeon-fandom-mrs-puff-spongebob.png");
        mNames.add("Ms. Puff");

        mImageUrls.add("https://i.dlpng.com/static/png/5498902-cartoon-characters-spongebob-squarepants-png-spongebob-characters-png-1196_1600_preview.png");
        mNames.add("Plankton");

        initRecyclerView();
    }

    private void initRecyclerView(){
        Log.d(TAG, "initRecyclerView: init recyclerview.");
        RecyclerView recyclerView = findViewById(R.id.recyclerv_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames, mImageUrls);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}






















